const info = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *Creator* : ${ownerName}
   ┠≽ *Version* : 2021
   ┠≽ *Youtube* : https://youtube.com/channel/UC6ZhjqSGko_wlOu28wrBnRw
   ┠≽ *Instagram* :https://www.instagram.com/wanbyone_m19/   
   ╰╼≽ *Developer © ${botName}`
}
exports.info = info
