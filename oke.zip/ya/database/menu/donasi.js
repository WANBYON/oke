const donasi = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉* 



◪ *DONASI*
  │
  ├─ ❏ 0896-9435-4384
  └─ ❏ 0896-9638-9730
   ╰╼≽ *Developer © ${botName}`
}
exports.donasi = donasi
