const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 USER INFO 〉*
   ╽
   ┠≽ *Name* : ${pushname}
   ┠≽ *XP* : ${reqXp}
   ┠≽ *Money* : ${uangku}
   ┠≽ *Registered :✅
   ╿
┯┷ *〈 BOT INFO 〉*
╽
┠≽ *Prefix* : 「  ${prefix}  」
┠≽ *Creator* : ${ownerName}
┠≽ *Version* : 0.0.4
╿
*〈 ABOUT 〉*
╽
┠≽ *${prefix}info*
┠≽ *${prefix}blocklist*
┠≽ *${prefix}chatlist* 
┠≽ *${prefix}ping*
┠≽ *${prefix}bug* 
┷┯ *〈 LIMIT 〉*
   ╽
   ┠≽ *${prefix}limit*
   ┠≽ *${prefix}bal*
   ┠≽ *${prefix}buylimit* 
*〈 LEVEL 〉*
   ╽
   ┠≽ *${prefix}level*
   ┠≽ *${prefix}leveling* (1/0)
   ┠≽ *${prefix}mining*
   ┠≽ *${prefix}event* (1/0)
*〈 STICKER MAKER 〉*
   ╽
   ┠≽ *${prefix}sticker*  
   ┠≽ *${prefix}stickergif*
   ┠≽ *${prefix}ttp*
*〈 IMAGE MAKER 〉*
   ╽
   ┠≽ *${prefix}bpink*
   ┠≽ *${prefix}snowwrite* (text|text)
   ┠≽ *${prefix}3dtext*
   ┠≽ *${prefix}firetext*
   ┠≽ *${prefix}glitch* (text|text)
   ┠≽ *${prefix}shadow*
   ┠≽ *${prefix}burnpaper* 
   ┠≽ *${prefix}coffee*
   ┠≽ *${prefix}lovepaper* 
   ┠≽ *${prefix}woodblock* 
   ┠≽ *${prefix}qowheart* 
   ┠≽ *${prefix}mutgrass* 
   ┠≽ *${prefix}undergocean*
   ┠≽ *${prefix}woodenboards*
   ┠≽ *${prefix}wolfmetal*
   ┠≽ *${prefix}metalictglow*   
   ┠≽ *${prefix}8bit* (text|text)
   ┠≽ *${prefix}herrypotter* 
 *〈 LOGO MAKER 〉*
   ╽
   ┠≽ *${prefix}ninjalogo* (text|text)
   ┠≽ *${prefix}logowolf* (text|text)
   ┠≽ *${prefix}logowolf2* (text|text)
   ┠≽ *${prefix}phlogo* (text|text)
   ┠≽ *${prefix}neonlogo*
   ┠≽ *${prefix}neonlogo2*
   ┠≽ *${prefix}lionlogo* (text|text)
   ┠≽ *${prefix}jokerlogo* 
   ┠≽ *${prefix}pubglogo* (text|text)
 *〈 18++ 〉*
   ╽
   ┠≽ *${prefix}randomhentai*
   ┠≽ *${prefix}nsfwtrap*
   ┠≽ *${prefix}nsfwneko*
*〈 DOWNLOADER 〉*
   ╽
   ┠≽ *${prefix}pinterest*
   ┠≽ *${prefix}ytmp3*
   ┠≽ *${prefix}ytmp4*
   ┠≽ *${prefix}tiktok*
*〈 ISLAM 〉*
   ╽
   ┠≽ *${prefix}quran*
   ┠≽ *${prefix}jsholat*
*〈 INFORMATION 〉*
   ╽
   ┠≽ *${prefix}bahasa*
   ┠≽ *${prefix}kodenegara*
   ┠≽ *${prefix}kbbi* 
   ┠≽ *${prefix}fakta*
   ┠≽ *${prefix}infocuaca* 
   ┠≽ *${prefix}infogempa*
   ┠≽ *${prefix}covidcountry*
*〈 EDUCATION 〉*
   ╽
   ┠≽ *${prefix}wiki*
   ┠≽ *${prefix}wikien* 
   ┠≽ *${prefix}nulis* 
   ┠≽ *${prefix}quotes*
   ┠≽ *${prefix}quotes2*
   ┠≽ *${prefix}tafsirmimpi*
   ┠≽ *${prefix}translate* 
*〈 STAY ON SCREEN 〉*
   ╽
   ┠≽ *${prefix}afk*
*〈 WEEBOO 〉*
   ╽
   ┠≽ *${prefix}neonime*
   ┠≽ *${prefix}pokemon*
   ┠≽ *${prefix}loli*
   ┠≽ *${prefix}waifu*
   ┠≽ *${prefix}randomanime*
   ┠≽ *${prefix}husbu2*
   ┠≽ *${prefix}wait*
   ┠≽ *${prefix}nekonime*
*〈 KERANG AJAIB 〉*
   ╽
   ┠≽ *${prefix}apakah* 
   ┠≽ *${prefix}bisakah* 
   ┠≽ *${prefix}kapankah* 
   ┠≽ *${prefix}watak*
   ┠≽ *${prefix}hobby*
   ┠≽ *${prefix}gantengcek*
   ┠≽ *${prefix}cantikcek*
*〈 MUSIC 〉*
   ╽
   ┠≽ *${prefix}play* 
   ┠≽ *${prefix}joox* 
   ┠≽ *${prefix}lirik* 
   ┠≽ *${prefix}chord* 
*〈 TEXT TO SPEACH 〉*
   ╽
   ┠≽ *${prefix}tts*
*〈 SEARCH 〉*
   ╽
   ┠≽ *${prefix}wait*
   ┠≽ *${prefix}ytsearch*
   ┠≽ *${prefix}trendtwit*
*〈 STALK 〉*
   ╽
   ┠≽ *${prefix}tiktokstalk* 
   ┠≽ *${prefix}igstalk* 
*〈 FUN 〉*
   ╽
   ┠≽ *${prefix}alay*
   ┠≽ *${prefix}bucin*
   ┠≽ *${prefix}trust*
   ┠≽ *${prefix}dare*
   ┠≽ *${prefix}simi* 
   ┠≽ *${prefix}artinama*
*〈 TRUTH OR DARE 〉*
   ╽
   ┠≽ *${prefix}truth*


   ┠≽ *${prefix}dare*
*〈 MEME 〉*
   ╽
   ┠≽ *${prefix}meme*
   ┠≽ *${prefix}memeindo*
*〈 GROUP 〉*
   ╽
   ┠≽ *${prefix}bukagc*
   ┠≽ *${prefix}tutupgc*
   ┠≽ *${prefix}promote*
   ┠≽ *${prefix}demote* 
   ┠≽ *${prefix}tagall*
   ┠≽ *${prefix}add* 
   ┠≽ *${prefix}kick*
   ┠≽ *${prefix}listadmins*
   ┠≽ *${prefix}linkgroup*
   ┠≽ *${prefix}leave*
   ┠≽ *${prefix}welcome* (1/0)
   ┠≽ *${prefix}nsfw* (1/0)
   ┠≽ *${prefix}delete*  
   ┠≽ *${prefix}simih* (1/0)
   ┠≽ *${prefix}tagme*
   ┠≽ *${prefix}ownergroup*
*〈 OWNER 〉*
   ╽
   ┠≽ *${prefix}setprefix* 
   ┠≽ *${prefix}block*
   ┠≽ *${prefix}unblock* 
   ┠≽ *${prefix}bc* 
   ┠≽ *${prefix}clone* 
   ┠≽ *${prefix}clearall*
*〈 OTHER 〉*
   ╽
   ┠≽ *${prefix}send*
   ┠≽ *${prefix}wame*
   ┠≽ *${prefix}virtex*
   ┠≽ *${prefix}qrcode*
   ┠≽ *${prefix}timer*
   ┠≽ *${prefix}fml*
   ┠≽ *${prefix}fml2*
   ╰╼≽ *Developer © ${botName}`
}
exports.help = help
