# apv1 
<hi align="center">WELCOME BACK TO <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="60px" alt="hi"><br>AGUSZ PAKEZ!</h1>

<p align="center">

  <img src="https://raw.githubusercontent.com/axfcap/axfcap/main/20210127_212936.jpg" />

</p>

<a href="https://www.facebook.com/aggusbudy.budy"><img src="https://image.flaticon.com/icons/svg/174/174848.svg" alt="alt text" width="20" height="20"></a>      &nbsp;&nbsp;   <a href="https://instagram.com/axfc_ap"><img src="https://image.flaticon.com/icons/svg/174/174855.svg" alt="alt text" width="20" height="20"></a>

 &nbsp;&nbsp; 

- 🌱 I’m currently learning **nothing**.

- 👀 I'm currently focusing on **JavaScript**.

- 📝 I'm currently working on [`axfc/apbotv1`](https://github.com/axcap/apbotv1)

- 👥 Subscribe channel kami [`YOUTUBE`](https://youtube.com/channel/UCKP-E8RwFkJKhe-9uz0s9RQ)

  <img src="https://raw.githubusercontent.com/TheDudeThatCode/TheDudeThatCode/master/Assets/Mario_Gameplay.gif"/>


## thanks to :
[NazwaS](https://github.com/NazwaS)














[MhankBarBar](https://github.com/MhankBarBar)
